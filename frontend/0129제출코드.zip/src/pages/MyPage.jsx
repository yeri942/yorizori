import React from "react";
import styled from "styled-components";
import Profile from '../Components/mypage/Profile'


const MyPage = () => {
  return (
    <div>
      <Profile />
    </div>
  );
};

export default MyPage;
