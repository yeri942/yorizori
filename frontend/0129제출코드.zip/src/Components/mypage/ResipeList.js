import React, { useState, useEffect} from 'react'

export default function ResipeButton() {
  const [onResipe, setOnResipe] = useState(false)
  
  const changeResipe = () => {
    setOnResipe((onResipe) => {
      console.log(onResipe)
      return !onResipe
    })
  }

  return (
    <div>
      {changeResipe}
    </div>
  )
}