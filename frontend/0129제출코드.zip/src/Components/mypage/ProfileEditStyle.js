import styled, { css } from "styled-components";
import { Link } from "react-router-dom";


export const MyPageEditInputBox = styled.div`
  width: 320px;
  height: 50px;
  align-items: center;
`


