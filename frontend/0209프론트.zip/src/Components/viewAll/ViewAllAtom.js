import { atom } from "recoil";

export const buttonState = atom({
  key: "buttonState",
  default: false,
});
