import React from "react";
import styled from "styled-components";
import PostDetail from "../Components/postDetail/PostDetail";

const PostDetailPage = () => {
  return (
    <div>
      <PostDetail />
    </div>
  );
};

export default PostDetailPage;
