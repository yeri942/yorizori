import React from "react";
import styled from "styled-components";
import ProfileEdit from '../Components/mypage/ProfileEdit'


const MyPageEdit = (props) => {
  console.log(props)
  return (
    <div>
      <ProfileEdit />
    </div>
  );
};

export default MyPageEdit;
